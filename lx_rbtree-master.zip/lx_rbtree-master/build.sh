#! /bin/sh

gcc -W -Werror -g  -o test lx_rbtree_test.c lx_rbtree.c


