/*************************************************************************
	> File Name: store_score.h
	> Author: suyelu 
	> Mail: suyelu@126.com
	> Created Time: Tue 07 Jul 2020 01:04:39 AM CST
 ************************************************************************/

#ifndef _STORE_SCORE_H
#define _STORE_SCORE_H
void store_score(char *testname, char *id, char *name, char *ip, double score);
#endif
