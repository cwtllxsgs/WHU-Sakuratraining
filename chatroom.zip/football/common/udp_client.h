/*************************************************************************
	> File Name: udp_client.h
	> Author: suyelu 
	> Mail: suyelu@126.com
	> Created Time: Thu 09 Jul 2020 11:56:07 AM CST
 ************************************************************************/

#ifndef _UDP_CLIENT_H
#define _UDP_CLIENT_H
int socket_udp();
#endif
