/*************************************************************************
	> File Name: client_recv.h
	> Author: 
	> Mail: 
	> Created Time: Fri 10 Jul 2020 08:05:43 PM CST
 ************************************************************************/

#ifndef _CLIENT_RECV_H
#define _CLIENT_RECV_H

void *client_recv(void *arg);
void *do_recv(void *arg);
#endif
