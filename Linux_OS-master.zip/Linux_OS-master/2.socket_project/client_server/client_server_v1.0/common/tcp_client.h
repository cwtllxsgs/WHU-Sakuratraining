/*************************************************************************
    > File Name: tcp_client.h
    > Author: ma6174
    > Mail: ma6174@163.com 
    > Created Time: Sat 28 Mar 2020 02:35:07 PM CST
 ************************************************************************/


#ifndef _TCP_CLIENT_H
#define _TCP_CLIENT_H

int socket_connect(char *host, int port);
#endif
