/*************************************************************************
    > File Name: tcp_server.h
    > Author: ma6174
    > Mail: ma6174@163.com 
    > Created Time: Sat 28 Mar 2020 02:24:45 PM CST
 ************************************************************************/


#ifndef _TCP_SERVER_H
#define _TCP_SERVER_H
int socket_create(int port);
#endif
