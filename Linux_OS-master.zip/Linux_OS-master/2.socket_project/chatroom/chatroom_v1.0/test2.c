/*************************************************************************
    > File Name: test2.c
    > Author: ma6174
    > Mail: ma6174@163.com 
    > Created Time: Sun 29 Mar 2020 07:00:05 PM CST
 ************************************************************************/

#include <stdio.h>
#include "color.h"

int main() {
	printf(RED"ls\n");
	return 0;
}
