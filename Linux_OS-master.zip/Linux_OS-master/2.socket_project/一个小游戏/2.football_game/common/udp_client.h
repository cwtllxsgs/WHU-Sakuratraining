/************************************************************
    File Name : udp_client.h
    Author: ltw
    Mail: 3245849061@qq.com
    Github: https://github.com/hello-sources
    Created Time: 2020/06/04 18:55:47
************************************************************/

#ifndef _UDP_CLIENT_H
#define _UDP_CLIENT_H
int socket_udp();
#endif
