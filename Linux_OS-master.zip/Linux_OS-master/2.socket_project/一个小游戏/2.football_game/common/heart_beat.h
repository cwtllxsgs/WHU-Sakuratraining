/*************************************************************************
	> File Name: heart_beat.h
	> Author: ltw
	> Mail: 3245849061@qq.com
	> Github: https://github.com/hello-sources
	> Created Time: Tue 09 Jun 2020 08:27:23 PM CST
 ************************************************************************/

#ifndef _HEART_BEAT_H
#define _HEART_BEAT_H
void *heart_beat(void *arg);
void heart_beat_team(struct User *team);
#endif
