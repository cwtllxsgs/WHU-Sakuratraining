/*************************************************************************
	> File Name: client_recver.h
	> Author: ltw
	> Mail: 3245849061@qq.com
	> Github: https://github.com/hello-sources
	> Created Time: Sat 13 Jun 2020 02:24:14 PM CST
 ************************************************************************/

#ifndef _CLIENT_RECVER_H
#define _CLIENT_RECVER_H
void *client_recv(void *arg);
#endif
