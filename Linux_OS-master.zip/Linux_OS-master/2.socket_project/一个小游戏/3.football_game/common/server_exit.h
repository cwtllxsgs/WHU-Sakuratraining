/*************************************************************************
	> File Name: server_exit.h
	> Author: ltw
	> Mail: 3245849061@qq.com
	> Github: https://github.com/hello-sources
	> Created Time: Sat 13 Jun 2020 02:44:21 PM CST
 ************************************************************************/

#ifndef _SERVER_EXIT_H
#define _SERVER_EXIT_H
void server_exit();
#endif
