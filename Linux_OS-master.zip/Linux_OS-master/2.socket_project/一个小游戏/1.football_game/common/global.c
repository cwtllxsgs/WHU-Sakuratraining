/************************************************************
    File Name : global.c
    Author: ltw
    Mail: 3245849061@qq.com
    Github: https://github.com/Ginakira
    Created Time: 2020/06/04 19:31:58
************************************************************/

char conf_ans[50] = {0};
