/************************************************************
    File Name : udp_server.h
    Author: ltw
    Mail: 3245849061@qq.com
    Github: https://github.com/Ginakira
    Created Time: 2020/05/28 19:11:11
************************************************************/

#ifndef _UDP_SERVER_H
#define _UDP_SERVER_H
int socket_create_udp(int port);
#endif
