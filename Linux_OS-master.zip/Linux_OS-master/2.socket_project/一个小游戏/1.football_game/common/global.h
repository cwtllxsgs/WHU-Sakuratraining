/************************************************************
    File Name : global.h
    Author: ltw
    Mail: 3245849061@qq.com
    Github: https://github.com/Ginakira
    Created Time: 2020/06/04 19:32:21
************************************************************/

#ifndef _GLOBAL_H
#define _GLOBAL_H
extern char conf_ans[50];
#endif
