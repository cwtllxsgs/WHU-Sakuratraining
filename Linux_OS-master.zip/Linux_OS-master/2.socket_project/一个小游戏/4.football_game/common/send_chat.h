/*************************************************************************
	> File Name: send_chat.h
	> Author: ltw
	> Mail: 3245849061@qq.com
	> Github: https://github.com/hello-sources
	> Created Time: Mon 15 Jun 2020 04:36:53 PM CST
 ************************************************************************/

#ifndef _SEND_CHAT_H
#define _SEND_CHAT_H
void send_chat();
#endif
