/*************************************************************************
	> File Name: send_ctl.h
	> Author: ltw
	> Mail: 3245849061@qq.com
	> Github: https://github.com/hello-sources
	> Created Time: Mon 15 Jun 2020 04:56:05 PM CST
 ************************************************************************/

#ifndef _SEND_CTL_H
#define _SEND_CTL_H
void send_ctl();
#endif
