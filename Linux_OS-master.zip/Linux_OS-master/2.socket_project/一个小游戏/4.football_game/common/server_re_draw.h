/*************************************************************************
	> File Name: server_re_draw.h
	> Author: ltw
	> Mail: 3245849061@qq.com
	> Github: https://github.com/hello-sources
	> Created Time: Mon 15 Jun 2020 06:13:05 PM CST
 ************************************************************************/

#ifndef _SERVER_RE_DRAW_H
#define _SERVER_RE_DRAW_H
void re_draw();
#endif
