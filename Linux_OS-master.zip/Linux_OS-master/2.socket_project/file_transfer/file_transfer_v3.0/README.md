# 修改说明
> 主要修改的就是recever.c中的write文件的功能，写入的是对应的packet.buf大小
