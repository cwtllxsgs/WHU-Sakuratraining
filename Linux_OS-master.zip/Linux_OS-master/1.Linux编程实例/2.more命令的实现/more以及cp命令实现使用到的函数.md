### more， cp命令的实现，使用到的函数



``` shell
$man fopen 
#打开文件
$man fseek
#移动文件流指针
$man fread
#读文件
$man fwrite
#写文件
$man fgets
#得到一些字符
$man fputs
#把字符串写道字符流中
$man open
#打开文件，按照ASCII码打开文件，返回值是int类型的，表示文件描述符，也可以创建文件
$man creat
#创建文件
$man write
#写文件
$man close
#文件关闭
```

